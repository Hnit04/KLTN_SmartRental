const fs = require('fs');
const path = require('path');

const filePath = path.join(
  'c:', 'Users', 'Tinh', 'Nam_4_1', 'mobile', 'HTH', 'KLTN_SmartRental',
  'backend', 'src', 'main', 'java', 'iuh', 'se', 'kltn', 'backend',
  'modules', 'ai', 'service', 'AiOrchestratorService.java'
);

let content = fs.readFileSync(filePath, 'utf8');

// Fix 1: clearSqlCache - replace removeAll() with filtered deletes
const oldRemoveAll = 'embeddingStore.removeAll(); // Xo\u00e1 tr\u00ean RAM (Vector Store)';
const newRemoveAll = `embeddingStore.removeAll(metadataKey("type").isEqualTo("SQL"));
        embeddingStore.removeAll(metadataKey("type").isEqualTo("FAQ"));`;

if (content.includes(oldRemoveAll)) {
  content = content.replace(oldRemoveAll, newRemoveAll);
  console.log('FIXED: clearSqlCache() removeAll() -> filtered deletes');
} else {
  console.log('NOT FOUND removeAll pattern, searching...');
  const idx = content.indexOf('clearSqlCache');
  if (idx >= 0) {
    console.log('Context around clearSqlCache:');
    console.log(JSON.stringify(content.substring(idx, idx + 300)));
  }
}

// Fix 2: Update log message
const oldMsg = '\u0110\u00e3 xo\u00e1 s\u1ea1ch Cache AI.';
const newMsg = '\u0110\u00e3 xo\u00e1 s\u1ea1ch SQL/FAQ Cache (gi\u1eef nguy\u00ean RAG documents).';
if (content.includes(oldMsg)) {
  content = content.replace(oldMsg, newMsg);
  console.log('FIXED: Updated log message');
}

fs.writeFileSync(filePath, content, 'utf8');
console.log('File saved successfully');
