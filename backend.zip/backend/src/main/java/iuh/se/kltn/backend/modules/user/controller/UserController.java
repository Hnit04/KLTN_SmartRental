package iuh.se.kltn.backend.modules.user.controller;

import iuh.se.kltn.backend.common.enums.Role;
import iuh.se.kltn.backend.common.security.UserPrincipal;
import iuh.se.kltn.backend.common.service.CloudinaryService;
import iuh.se.kltn.backend.common.service.OcrService;
import iuh.se.kltn.backend.modules.user.dto.request.UpdateProfileRequest;
import iuh.se.kltn.backend.modules.user.dto.response.UserHistoryResponse;
import iuh.se.kltn.backend.modules.user.dto.response.UserProfileResponse;
import iuh.se.kltn.backend.modules.user.entity.CustomRevisionEntity;
import iuh.se.kltn.backend.modules.user.entity.User;
import iuh.se.kltn.backend.modules.user.repository.ReputationHistoryRepository;
import iuh.se.kltn.backend.modules.user.dto.response.ReputationHistoryResponse;
import iuh.se.kltn.backend.modules.user.repository.UserRepository;
import iuh.se.kltn.backend.modules.user.service.UserService;
import jakarta.persistence.EntityManager;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.query.AuditEntity;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/users")
@Validated
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ReputationHistoryRepository reputationHistoryRepository;

    @Autowired
    private CloudinaryService cloudinaryService;

    @Autowired
    private OcrService ocrService;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private ModelMapper modelMapper;


    @GetMapping("/me")
    public ResponseEntity<UserProfileResponse> getCurrentUser(@AuthenticationPrincipal UserPrincipal currentUser) {
        UserProfileResponse userProfile = userService.getUserProfile(currentUser.getId());
        return ResponseEntity.ok(userProfile);
    }

    @GetMapping("/me/reputation-history")
    public ResponseEntity<List<ReputationHistoryResponse>> getReputationHistory(@AuthenticationPrincipal UserPrincipal currentUser) {
        List<ReputationHistoryResponse> history = reputationHistoryRepository.findByUserIdOrderByCreatedAtDesc(currentUser.getId())
                .stream()
                .map(item -> new ReputationHistoryResponse(
                        item.getId(),
                        item.getUser().getId(),
                        item.getActionType().name(),
                        item.getPointsChanged(),
                        item.getDescription(),
                        item.getCreatedAt()
                ))
                .collect(Collectors.toList());
        return ResponseEntity.ok(history);
    }
    @GetMapping("/username")
    public UserProfileResponse findByUsername(@RequestParam @NotBlank String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.isLocked() && user.getLockUntil() != null) {
            if (user.getLockUntil().isBefore(LocalDateTime.now())) {
                user.setLocked(false);
                user.setLockUntil(null);
                user.setLockReason(null);
                userRepository.save(user);
            }
        }

        return modelMapper.map(user, UserProfileResponse.class);
    }

    @PutMapping("/profile")
    public ResponseEntity<UserProfileResponse> updateProfile(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @Valid @RequestBody UpdateProfileRequest request) {

        UserProfileResponse response = userService.updateUserProfile(currentUser.getId(), request);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/wallet")
    public ResponseEntity<?> updateWallet(@AuthenticationPrincipal UserPrincipal currentUser,
                                          @RequestParam
                                          @NotBlank
                                          @Pattern(regexp = "^0x[a-fA-F0-9]{40}$", message = "Wallet address must be a valid EVM address")
                                          String address) {
        userService.updateWalletAddress(currentUser.getId(), address);
        return ResponseEntity.ok("Cập nhật ví thành công!");
    }

    @PostMapping(value = "/avatar", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> uploadAvatar(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam("file") MultipartFile file) {

        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body("File không được để trống");
            }

            // ✅ SỬA LỖI TẠI ĐÂY: Dùng hàm uploadAvatar đã định nghĩa trong CloudinaryService
            String avatarUrl = cloudinaryService.uploadAvatar(file);

            userService.updateAvatar(currentUser.getId(), avatarUrl);

            return ResponseEntity.ok(avatarUrl);

        } catch (IOException e) {
            return ResponseEntity.internalServerError().body("Lỗi upload ảnh: " + e.getMessage());
        }
    }

    @PostMapping(value = "/qr", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> uploadQr(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam("file") MultipartFile file) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body("File không được để trống");
            }
            String qrUrl = cloudinaryService.uploadImage(file, "smart-rental/qr");
            return ResponseEntity.ok(qrUrl);
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body("Lỗi upload ảnh QR: " + e.getMessage());
        }
    }

    @PostMapping("/kyc/extract")
    public ResponseEntity<?> extractKYCInfo(@RequestParam("image") MultipartFile image) {
        String extractedId = ocrService.extractIdNumber(image);
        if (extractedId == null) {
            return ResponseEntity.badRequest().body("Không thể trích xuất thông tin từ ảnh");
        }
        return ResponseEntity.ok(java.util.Map.of("id", extractedId));
    }

    @PostMapping(value = "/kyc", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> submitKYC(
            @AuthenticationPrincipal UserPrincipal currentUser,
            @RequestParam("cccdNumber") String cccdNumber,
            @RequestParam("frontImage") MultipartFile frontImage,
            @RequestParam("backImage") MultipartFile backImage) {

        try {
            User user = userRepository.findById(currentUser.getId()).orElseThrow();
            
            // 1. Kiểm tra giới hạn lượt thử
            boolean canUseOCR = user.getKycAttempts() < 3;
            boolean isAutoVerified = false;

            String frontUrl = "";
            String backUrl = "";

            if (canUseOCR) {
                System.out.println("Đang gửi ảnh sang FPT.AI (Lượt thử: " + (user.getKycAttempts() + 1) + ")...");
                String extractedId = ocrService.extractIdNumber(frontImage);
                
                if (extractedId != null && extractedId.equals(cccdNumber)) {
                    isAutoVerified = true;
                }
            }

            // 2. Upload ảnh vào folder Private/Authenticated
            frontUrl = cloudinaryService.uploadPrivateImage(frontImage, "smart-rental/kyc");
            backUrl = cloudinaryService.uploadPrivateImage(backImage, "smart-rental/kyc");

            // 3. Cập nhật database và tăng số lượt thử
            userService.submitKYC(user.getId(), cccdNumber, frontUrl, backUrl, isAutoVerified);

            if (isAutoVerified) {
                // 4. Xóa ảnh ngay lập tức nếu xác thực thành công (theo yêu cầu bảo mật)
                cloudinaryService.deleteImage(frontUrl);
                cloudinaryService.deleteImage(backUrl);
                return ResponseEntity.ok("Xác thực danh tính thành công! Dữ liệu hình ảnh đã được xóa để bảo mật.");
            } else {
                if (!canUseOCR) {
                    return ResponseEntity.ok("Bạn đã hết lượt xác thực tự động. Hồ sơ đã được gửi để Admin duyệt thủ công.");
                }
                return ResponseEntity.ok("Thông tin không khớp hoặc ảnh mờ. Hồ sơ đang chờ Admin duyệt thủ công.");
            }

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Lỗi xử lý: " + e.getMessage());
        }
    }

    @GetMapping("/kyc/pending")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<UserProfileResponse>> getPendingKYC() {
        return ResponseEntity.ok(userService.getPendingKYCUsers());
    }

    @PostMapping("/kyc/{userId}/verify")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> verifyKYC(
            @PathVariable Long userId,
            @RequestParam(required = false) String cccdNumber) {
        try {
            userService.verifyKYCAdmin(userId, cccdNumber);
            return ResponseEntity.ok("Đã phê duyệt định danh người dùng ID " + userId);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Lỗi: " + e.getMessage());
        }
    }

    @PostMapping("/kyc/{userId}/reject")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> rejectKYC(@PathVariable Long userId, @RequestParam @NotBlank String reason) {
        try {
            userService.rejectKYCAdmin(userId, reason);
            return ResponseEntity.ok("Đã từ chối định danh người dùng ID " + userId + ". Lý do: " + reason);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Lỗi: " + e.getMessage());
        }
    }

    @GetMapping("/by-role")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<UserProfileResponse>> getUsersByRole(
            @RequestParam Role role,
            @AuthenticationPrincipal UserPrincipal currentUser) {
        List<UserProfileResponse> users = userService.getAllByRole(role);
        return ResponseEntity.ok(users);
    }

    @GetMapping("/top-landlords")
    public ResponseEntity<List<UserProfileResponse>> getTopLandlords(
            @RequestParam(defaultValue = "10") @Min(1) @Max(100) int limit) {
        List<UserProfileResponse> topLandlords = userService.getTopLandlords(limit);
        return ResponseEntity.ok(topLandlords);
    }

    @Transactional
    @PostMapping("/{userId}/lock")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> lockUser(
            @PathVariable Long userId,
            @RequestParam @Min(1) int durationDays,
            @RequestParam List<String> reason,
            @AuthenticationPrincipal UserPrincipal admin) {

        // Có thể thêm validation
        if (durationDays <= 0) {
            return ResponseEntity.badRequest().body("Số ngày khóa phải lớn hơn 0");
        }
        if (reason == null) {
            return ResponseEntity.badRequest().body("Vui lòng cung cấp lý do khóa tài khoản");
        }

        userService.lockUserTemporary(userId, durationDays, reason);

        return ResponseEntity.ok(String.format("Tài khoản ID %d đã bị khóa %d ngày. Lý do: %s",
                userId, durationDays, reason));
    }

    @Transactional
    @PostMapping("/{userId}/unlock")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> unlockUser(@PathVariable Long userId) {
        userService.unlockUser(userId);
        return ResponseEntity.ok("Đã mở khóa tài khoản ID " + userId);
    }
    @GetMapping("/{userId}/history")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<UserHistoryResponse>> getUserAuditHistory(@PathVariable Long userId) {

        AuditReader auditReader = AuditReaderFactory.get(entityManager);

        // Lấy tất cả revision của User, sắp xếp theo thời gian tăng dần để so sánh cặp
        @SuppressWarnings("unchecked")
        List<Object[]> revisions = auditReader.createQuery()
                .forRevisionsOfEntity(User.class, false, true)
                .add(AuditEntity.id().eq(userId))
                .addOrder(AuditEntity.revisionNumber().asc()) // Quan trọng: Sắp xếp cũ -> mới để so sánh
                .getResultList();

        List<UserHistoryResponse> filteredHistory = new ArrayList<>();
        User previousState = null;

        for (Object[] row : revisions) {
            User currentState = (User) row[0];
            CustomRevisionEntity revInfo = (CustomRevisionEntity) row[1];
            // row[2] thường là RevisionType (ADD, MOD, DEL)

            // Kiểm tra điều kiện:
            // 1. Nếu là bản ghi đầu tiên (ADD) và tài khoản đang bị khóa
            // 2. Hoặc nếu trạng thái isLocked thay đổi so với bản ghi trước đó
            boolean isLockStatusChanged = (previousState == null && currentState.getIsLocked())
                    || (previousState != null && previousState.getIsLocked() != currentState.getIsLocked());

            if (isLockStatusChanged) {
                UserHistoryResponse dto = modelMapper.map(currentState, UserHistoryResponse.class);

                if (revInfo != null) {
                    dto.setModifiedBy(revInfo.getModifiedBy());
                    dto.setModifiedByFullName(revInfo.getModifiedByFullName());

                    Instant instant = Instant.ofEpochMilli(revInfo.getTimestamp());
                    dto.setModifiedAt(LocalDateTime.ofInstant(instant, ZoneId.systemDefault()));

                    dto.setAuditRemark(revInfo.getAuditRemark());

                    // Thêm logic mô tả hành động (tùy chọn)
                    String action = currentState.getIsLocked() ? "KHÓA TÀI KHOẢN" : "MỞ KHÓA TÀI KHOẢN";
                    // Bạn có thể set action này vào một field trong DTO nếu có
                }
                filteredHistory.add(dto);
            }

            // Cập nhật trạng thái trước đó cho vòng lặp sau
            previousState = currentState;
        }

        // Đảo ngược danh sách để hiển thị cái mới nhất lên đầu
        Collections.reverse(filteredHistory);

        return ResponseEntity.ok(filteredHistory);
    }
    @GetMapping("/userId")
    public Optional<User> findById(@RequestParam @NotBlank String username){
        return userRepository.findByUsername(username);
    }
}
