-- ================================================================
-- SEED: Knowledge Documents for RAG Pipeline
-- Reference only: runtime seeds from seed_knowledge_data.tsv
-- ================================================================

-- 1. Chính sách thuê phòng SmartRental
INSERT INTO knowledge_documents (id, title, content, source, version, status, content_hash, created_at, updated_at)
VALUES (
    'policy-rental',
    'Chính sách thuê phòng SmartRental',
    'CHÍNH SÁCH THUÊ PHÒNG TRỌ SMARTRENTAL\n\n1. QUY TRÌNH THUÊ PHÒNG:\n- Bước 1: Tìm kiếm phòng trọ phù hợp trên ứng dụng SmartRental. Hệ thống hỗ trợ lọc theo khu vực, giá thuê, diện tích, tiện nghi.\n- Bước 2: Xem chi tiết phòng, hình ảnh thực tế, đánh giá từ người thuê trước.\n- Bước 3: Đặt lịch xem phòng trực tiếp qua tính năng Đặt lịch hẹn. Chủ trọ xác nhận lịch trong mục lịch hẹn.\n- Bước 4: Sau khi xem phòng và đồng ý, tiến hành ký hợp đồng điện tử trên ứng dụng.\n- Bước 5: Thanh toán tiền cọc và tiền thuê tháng đầu theo phương thức được hai bên chọn trong hệ thống.\n\n2. QUY ĐỊNH VỀ ĐẶT CỌC:\n- Tiền cọc do hai bên thỏa thuận và được ghi trong hợp đồng.\n- Hệ thống hiện ghi nhận thông tin tiền cọc, trạng thái đặt cọc và lịch sử xử lý theo hợp đồng.\n- Khi kết thúc hợp đồng, trạng thái thanh lý/hoàn cọc được cập nhật theo xác nhận của các bên và quy trình quản trị hiện có.\n- Trường hợp chấm dứt hợp đồng trước hạn từ phía người thuê hoặc chủ trọ: mức khấu trừ/bồi thường thực hiện theo điều khoản đã ký.\n\n3. QUY ĐỊNH VỀ GIA HẠN HỢP ĐỒNG:\n- Trước khi hợp đồng hết hạn, hệ thống hiện hỗ trợ nhắc lịch theo dữ liệu hợp đồng đang có.\n- Người thuê có thể gửi đề xuất gia hạn trực tiếp trên ứng dụng.\n- Giá thuê khi gia hạn được cập nhật theo thỏa thuận mới giữa hai bên.',
    'INTERNAL',
    'v1',
    'PUBLISHED',
    'seed-policy-rental-v1',
    NOW(),
    NOW()
);

-- 2. Chính sách thanh toán và hóa đơn
INSERT INTO knowledge_documents (id, title, content, source, version, status, content_hash, created_at, updated_at)
VALUES (
    'policy-payment',
    'Chính sách thanh toán và hóa đơn',
    'CHÍNH SÁCH THANH TOÁN VÀ HÓA ĐƠN SMARTRENTAL\n\n1. HÌNH THỨC THANH TOÁN:\n- Chuyển khoản ngân hàng qua mã QR tích hợp trong ứng dụng.\n- Thanh toán bằng tiền mã hóa (Cryptocurrency) qua ví MetaMask trên mạng Ethereum Sepolia.\n- Tiền mặt (chủ trọ xác nhận trên hệ thống).\n\n2. CHU KỲ THANH TOÁN:\n- Tiền thuê phòng thanh toán theo kỳ hóa đơn.\n- Hạn thanh toán (deadline) hiện do chủ trọ thiết lập khi tạo hóa đơn.\n- Hóa đơn điện nước được chủ trọ tạo trên hệ thống sau khi ghi chỉ số mới.\n- Hệ thống tính tiền điện, nước, dịch vụ dựa trên đơn giá đã cấu hình.\n\n3. QUY ĐỊNH THANH TOÁN TRỄ HẠN:\n- Khi quá deadline của hóa đơn, hệ thống ghi nhận là trễ hạn.\n- Hệ thống hiện hỗ trợ AI soạn nhắc nợ để chủ trọ duyệt và gửi thông báo.\n- Việc áp dụng phí phạt thực hiện theo điều khoản hợp đồng và thao tác xác nhận của người quản lý.\n\n4. HÓA ĐƠN ĐIỆN TỬ:\n- Tất cả hóa đơn được lưu trữ điện tử trên hệ thống và có thể tra cứu.\n- Người thuê có thể xem lịch sử thanh toán, chi tiết tiêu thụ điện nước theo tháng.\n- Chủ trọ có thể xuất báo cáo doanh thu theo khu trọ, theo tháng, theo năm.',
    'INTERNAL',
    'v1',
    'PUBLISHED',
    'seed-policy-payment-v1',
    NOW(),
    NOW()
);

-- 3. Quy định đăng tin và kiểm duyệt AI
INSERT INTO knowledge_documents (id, title, content, source, version, status, content_hash, created_at, updated_at)
VALUES (
    'policy-moderation',
    'Quy định đăng tin và kiểm duyệt AI',
    'QUY ĐỊNH ĐĂNG TIN VÀ KIỂM DUYỆT NỘI DUNG SMARTRENTAL\n\n1. QUY ĐỊNH ĐĂNG TIN:\n- Mỗi phòng trọ cần có hình ảnh thực tế rõ nét.\n- Mô tả phòng cần trung thực, đầy đủ thông tin: diện tích, giá thuê, tiện nghi, địa chỉ.\n- Nghiêm cấm đăng hình ảnh không liên quan, hình ảnh phản cảm, hoặc gây nhầm lẫn.\n\n2. KIỂM DUYỆT NỘI DUNG CÓ HỖ TRỢ AI:\n- Hệ thống dùng AI để so khớp ảnh và mô tả, sau đó chấm điểm an toàn 0-100.\n- Kết quả AI được lưu kèm lý do để phục vụ kiểm duyệt.\n- Hệ thống hiện ghi nhận bài đăng ở trạng thái chờ duyệt để Admin xử lý duyệt/từ chối.\n\n3. VI PHẠM VÀ XỬ LÝ:\n- Admin áp dụng mức xử lý theo quy định vận hành tại từng thời điểm.\n- Chủ trọ có thể khiếu nại qua kênh hỗ trợ theo quy trình hiện hành.',
    'INTERNAL',
    'v1',
    'PUBLISHED',
    'seed-policy-moderation-v1',
    NOW(),
    NOW()
);

-- 4. Quy trình xác minh danh tính eKYC
INSERT INTO knowledge_documents (id, title, content, source, version, status, content_hash, created_at, updated_at)
VALUES (
    'policy-ekyc',
    'Quy trình xác minh danh tính eKYC',
    'QUY TRÌNH XÁC MINH DANH TÍNH (eKYC) SMARTRENTAL\n\n1. MỤC ĐÍCH:\n- Hệ thống hiện ghi nhận hồ sơ định danh để tăng độ tin cậy tài khoản.\n- Kết quả định danh được dùng trong các luồng cần xác thực người dùng.\n\n2. QUY TRÌNH HIỆN CÓ:\n- Bước 1: Người dùng gửi số CCCD và 2 ảnh giấy tờ (mặt trước, mặt sau).\n- Bước 2: Hệ thống hiện cho phép OCR ảnh mặt trước để đối chiếu số CCCD trong giới hạn lượt thử tự động.\n- Bước 3: Nếu đối chiếu khớp, hồ sơ được xác nhận theo luồng tự động hiện có.\n- Bước 4: Nếu không khớp hoặc hết lượt tự động, hồ sơ được ghi nhận ở trạng thái chờ duyệt để Admin xử lý duyệt/từ chối.\n\n3. QUẢN TRỊ DỮ LIỆU KYC:\n- Ảnh giấy tờ được tải lên vùng lưu trữ private theo luồng hiện hành.\n- Khi xác thực tự động thành công, hệ thống hiện cho phép xóa ảnh theo quy trình bảo mật đang áp dụng.\n- Với hồ sơ chờ duyệt, Admin có thể xác minh thủ công hoặc từ chối kèm lý do.',
    'INTERNAL',
    'v1',
    'PUBLISHED',
    'seed-policy-ekyc-v1',
    NOW(),
    NOW()
);

-- 5. Hướng dẫn sử dụng dành cho khách thuê
INSERT INTO knowledge_documents (id, title, content, source, version, status, content_hash, created_at, updated_at)
VALUES (
    'guide-tenant',
    'Hướng dẫn sử dụng dành cho khách thuê',
    'HƯỚNG DẪN SỬ DỤNG SMARTRENTAL CHO KHÁCH THUÊ\n\n1. TÌM PHÒNG TRỌ:\n- Mở ứng dụng SmartRental, vào mục Tìm phòng.\n- Sử dụng bộ lọc: Khu vực, Quận/Huyện, Khoảng giá, Diện tích, Loại phòng, Tiện nghi.\n- Nhấn vào phòng để xem chi tiết, hình ảnh và bản đồ vị trí.\n\n2. ĐẶT LỊCH XEM PHÒNG:\n- Trong trang chi tiết phòng, nhấn nút Đặt lịch hẹn.\n- Chọn ngày giờ mong muốn.\n- Theo dõi phản hồi xác nhận/đề xuất lại của chủ trọ trong mục lịch hẹn.\n\n3. KÝ HỢP ĐỒNG ĐIỆN TỬ:\n- Sau khi thống nhất, chủ trọ tạo hợp đồng điện tử trên hệ thống.\n- Bạn xem lại điều khoản và xác nhận ký.\n- Dữ liệu hợp đồng được lưu trữ theo luồng xử lý hiện có của hệ thống.\n\n4. THANH TOÁN VÀ HÓA ĐƠN:\n- Vào mục Hóa đơn để xem các khoản phải thanh toán.\n- Chọn phương thức thanh toán phù hợp.\n- Khi giao dịch được xác nhận, hóa đơn được cập nhật là đã thanh toán trên hệ thống.\n\n5. SỬ DỤNG AI CHATBOT:\n- Luồng chat hiện ưu tiên FAQ semantic cache.\n- Nếu không khớp FAQ, hệ thống mới chuyển qua AI/RAG để trả lời tham khảo.\n- Với truy vấn dữ liệu, dùng endpoint tra cứu để lấy số liệu theo quyền truy cập.',
    'INTERNAL',
    'v1',
    'PUBLISHED',
    'seed-guide-tenant-v1',
    NOW(),
    NOW()
);

-- 6. Hướng dẫn sử dụng dành cho chủ trọ
INSERT INTO knowledge_documents (id, title, content, source, version, status, content_hash, created_at, updated_at)
VALUES (
    'guide-landlord',
    'Hướng dẫn sử dụng dành cho chủ trọ',
    'HƯỚNG DẪN SỬ DỤNG SMARTRENTAL CHO CHỦ TRỌ\n\n1. ĐĂNG PHÒNG CHO THUÊ:\n- Vào mục Quản lý khu trọ, thêm khu trọ mới và nhập thông tin cơ bản.\n- Thêm phòng: tên phòng, diện tích, giá thuê, tiện nghi, hình ảnh.\n- Hệ thống hiện dùng AI để chấm điểm nội dung và lưu lý do kiểm duyệt.\n- Bài đăng mới được ghi nhận ở trạng thái chờ duyệt để Admin duyệt trước khi hiển thị công khai.\n\n2. QUẢN LÝ HỢP ĐỒNG:\n- Tạo hợp đồng mới cho người thuê trong mục Hợp đồng.\n- Theo dõi trạng thái hợp đồng theo màn hình hệ thống, ví dụ: chờ ký, chờ đặt cọc, đang hiệu lực, đã hết hạn, đã chấm dứt sớm, đã hủy.\n\n3. GHI HÓA ĐƠN ĐIỆN NƯỚC:\n- Vào mục Hóa đơn, tạo hóa đơn mới.\n- Nhập chỉ số điện/nước và deadline thanh toán.\n- Hệ thống tính tiền dựa trên đơn giá đã cấu hình.\n\n4. XEM BÁO CÁO DOANH THU:\n- Vào mục Thống kê để xem doanh thu theo tháng và theo khu trọ.\n- Có thể dùng AI query-data để tra cứu số liệu theo quyền của chủ trọ.\n\n5. CÔNG CỤ AI HỖ TRỢ:\n- Soạn nhắc nợ: AI hỗ trợ tạo nội dung, chủ trọ duyệt rồi gửi.\n- Phân tích bất thường điện nước: AI hỗ trợ phân tích từ dữ liệu hóa đơn.\n- Gợi ý giá phòng và phân tích hợp đồng: dùng theo luồng thao tác hiện có trong hệ thống.',
    'INTERNAL',
    'v1',
    'PUBLISHED',
    'seed-guide-landlord-v1',
    NOW(),
    NOW()
);

-- 7. Hướng dẫn sử dụng AI Chatbot SmartRental
INSERT INTO knowledge_documents (id, title, content, source, version, status, content_hash, created_at, updated_at)
VALUES (
    'guide-ai',
    'Hướng dẫn sử dụng AI Chatbot SmartRental',
    'HƯỚNG DẪN SỬ DỤNG AI CHATBOT SMARTRENTAL\n\n1. CHATBOT TRỢ LÝ ẢO (POST /api/ai/chat):\n- Hỏi đáp chính sách, quy trình, hướng dẫn sử dụng.\n- Luồng hiện tại ưu tiên FAQ semantic cache trước; khi FAQ không khớp mới chuyển qua AI/RAG.\n- Phù hợp cho câu hỏi tư vấn, giải thích, tổng hợp thông tin.\n\n2. TRA CỨU DỮ LIỆU (POST /api/ai/query-data):\n- Dùng để lấy số liệu hóa đơn, hợp đồng, doanh thu theo quyền truy cập.\n- Dữ liệu truy vấn trực tiếp từ hệ thống nghiệp vụ.\n\n3. CÂU HỎI MẪU CHO KHÁCH THUÊ:\n- Tìm phòng trọ giá rẻ ở Gò Vấp.\n- Hóa đơn tháng này của tôi bao nhiêu?\n- Khi nào hợp đồng của tôi hết hạn?\n\n4. CÂU HỎI MẪU CHO CHỦ TRỌ:\n- Doanh thu khu trọ A tháng này?\n- Phòng nào đang trống?\n- Phòng nào đang nợ tiền?\n\n5. LƯU Ý QUAN TRỌNG:\n- Kết quả /api/ai/chat mang tính hỗ trợ tham khảo.\n- Kết quả /api/ai/query-data phản ánh dữ liệu theo quyền truy cập hiện hành.',
    'INTERNAL',
    'v1',
    'PUBLISHED',
    'seed-guide-ai-v1',
    NOW(),
    NOW()
);

-- 8. Gói VIP và quyền lợi chủ trọ
INSERT INTO knowledge_documents (id, title, content, source, version, status, content_hash, created_at, updated_at)
VALUES (
    'policy-vip',
    'Gói VIP và quyền lợi chủ trọ',
    'GÓI VIP VÀ QUYỀN LỢI CHỦ TRỌ SMARTRENTAL\n\n1. CÁC GÓI DỊCH VỤ:\n- Gói Miễn phí: giới hạn số phòng/ảnh theo cấu hình hiện hành.\n- Gói trả phí: mở rộng giới hạn và thêm công cụ hỗ trợ quản lý.\n\n2. QUYỀN LỢI GÓI TRẢ PHÍ:\n- Tăng giới hạn đăng bài, ảnh và một số tiện ích AI.\n- Hỗ trợ theo dõi chỉ số vận hành, nhắc nợ, phân tích dữ liệu theo phạm vi gói.\n- Chi tiết quyền lợi phụ thuộc tier đang kích hoạt trong hệ thống.\n\n3. THANH TOÁN VÀ HIỆU LỰC:\n- Gói VIP kích hoạt sau khi đơn hàng được ghi nhận thanh toán thành công.\n- Mỗi lần thanh toán gia hạn thêm chu kỳ theo cấu hình hiện hành.\n- Hết hạn sẽ được chuyển về FREE theo lịch xử lý của hệ thống.',
    'INTERNAL',
    'v1',
    'PUBLISHED',
    'seed-policy-vip-v1',
    NOW(),
    NOW()
);

