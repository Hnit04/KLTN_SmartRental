import os

path = r'c:\Users\Tinh\Nam_4_1\mobile\HTH\KLTN_SmartRental\backend\src\main\java\iuh\se\kltn\backend\modules\ai\service\AiOrchestratorService.java'

with open(path, 'r', encoding='utf-8') as f:
    content = f.read()

old_line = 'embeddingStore.removeAll(); // Xo\u00e1 tr\u00ean RAM (Vector Store)'
new_lines = '''embeddingStore.removeAll(metadataKey("type").isEqualTo("SQL"));
        embeddingStore.removeAll(metadataKey("type").isEqualTo("FAQ"));'''

if old_line in content:
    content = content.replace(old_line, new_lines, 1)
    # Also fix the log message
    content = content.replace(
        'System.out.println("\u2728 \u0110\u00e3 xo\u00e1 s\u1ea1ch Cache AI.");',
        'System.out.println("\u2728 \u0110\u00e3 xo\u00e1 s\u1ea1ch SQL/FAQ Cache (gi\u1eef nguy\u00ean RAG documents).");'
    )
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    print('FIXED: clearSqlCache() now uses filtered deletes')
else:
    print('NOT FOUND: already fixed or different encoding')
    # Debug: show nearby content
    idx = content.find('clearSqlCache')
    if idx >= 0:
        print('Context:', repr(content[idx:idx+300]))
